package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import testng.api.base.Annotations;

public class EntityPage extends Annotations {

	public AddEntityPage clickOnAddEntityButton() throws InterruptedException {
		WebElement result = locateElement("btnAddEntity");
		waitUntilClickable(result);		
		Thread.sleep(2000);
		WebElement addButton = locateElement("btnAddEntity");
		click(addButton);
		return new AddEntityPage();
	}
	
	public EntityPage clearEntityName() {
		WebElement entityName = locateElement("fSearchName");
		clear(entityName);
		return this;
	}


	public EntityPage enterIdentifier() {
		WebElement indentifier = locateElement("fContactPerson");
		clearAndType(indentifier, randomNumber);
		return this;

	}

	public EntityPage clickOnSearch() throws InterruptedException {
		Thread.sleep(2000);
		WebElement search = locateElement("btnSearchEntity");
		waitUntilClickable(search);
		click(search);
		return this;
	}

	public HomePage verifyCreatedEntityidentifier() throws InterruptedException {
		
		WebElement CIK1 = locateElement("xpath", "//tbody[@id='entity-tbody']//td[4]");
		waitUntilClickable(CIK1);		
		Thread.sleep(2000);

		WebElement resultTable = locateElement("entity-tbody");
		List<WebElement> resultList = resultTable.findElements(By.tagName("tr"));
		WebElement CIK = locateElement("xpath", "//tbody[@id='entity-tbody']//td[4]");
		System.out.println(resultList.size());
		System.out.println(getElementText(CIK));
		if (resultList.size() >=1 && getElementText(CIK).equals(randomNumber)) {
			reportStep("Entity created successfully.", "pass");
		} else
			reportStep("Entity not created successfully.", "fail");
		return new HomePage();
	}

	public EntityPage enterEntityName(String data) {
		WebElement eName = locateElement("fSearchName");
		clearAndType(eName, data);
		return this;

	}

	public EntityPage enterWebsite(String data) {
		WebElement email = locateElement("fEmail");
		clearAndType(email, data);
		return this;

	}
	
	public EntityPage clickOnActiveButton() {
		WebElement edit = locateElement("fActive");
		click(edit);
		return this;

	}
	
	public EditEntityPage clickOnEditEntity() throws InterruptedException {
		Thread.sleep(2000);
		WebElement edit = locateElement("xpath", "(//a[contains(@class,'EntityEditLink btn-xs')]//i)[1]");
		waitUntilClickable(edit);
		click(edit);
		return new EditEntityPage();

	}
	
	public EntityPage verifyInactiveIndertifier(String data) throws InterruptedException {
		Thread.sleep(2000);
		WebElement result = locateElement("xpath","//tbody[@id='entity-tbody']//td[2]");
		waitUntilVisibility(result);
		verifyPartialText(result, data);
		return this;

		
	}
	
	

}
